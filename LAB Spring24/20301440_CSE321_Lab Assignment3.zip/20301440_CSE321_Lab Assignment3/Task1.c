#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/shm.h>
#include <string.h>

#define SHM_SIZE 1024

struct shared {
    char sel[100];
    int b;
};

int main() {
    int shm_id;
    struct shared *shm_ptr;
    int p[2];

    shm_id = shmget(IPC_PRIVATE, SHM_SIZE, IPC_CREAT | 0666);
    if (shm_id < 0) {
        perror("shmget");
        exit(1);
    }

    shm_ptr = (struct shared *)shmat(shm_id, NULL, 0);
    if (shm_ptr == (void *)-1) {
        perror("shmat");
        exit(1);
    }

    if (pipe(p) == -1) {
        perror("pipe");
        exit(1);
    }

    pid_t pid = fork();

    if (pid < 0) {
        perror("fork");
        exit(1);
    } else if (pid == 0) {
        close(p[1]);
        read(p[0], shm_ptr, sizeof(struct shared));

        if (strcmp(shm_ptr->sel, "a") == 0) {
            int amount;
            printf("Your selection: %s\n\nEnter amount to be added:\n", shm_ptr->sel);
            scanf("%d", &amount);
            if (amount > 0) {
                shm_ptr->b += amount;
                printf("Balance added successfully\nUpdated balance after addition: %d\n", shm_ptr->b);
            } else {
                printf("Adding failed, Invalid amount\n");
            }
        } else if (strcmp(shm_ptr->sel, "w") == 0) {
            printf("Your selection: %s\n\nEnter amount to be withdrawn:\n", shm_ptr->sel);
            int amount;
            scanf("%d", &amount);
            if (amount > 0 && amount <= shm_ptr->b) {
                shm_ptr->b -= amount;
                printf("Balance withdrawn successfully\nUpdated balance after withdrawal: %d\n", shm_ptr->b);
            } else {
                printf("Withdrawal failed, Invalid amount\n");
            }
        } else if (strcmp(shm_ptr->sel, "c") == 0) {
            printf("Your selection: %s\n\nYour current balance is: %d\n", shm_ptr->sel, shm_ptr->b);
        } else {
            printf("Your selection: %s\n\nInvalid selection\n", shm_ptr->sel);
        }

        close(p[0]);
        write(p[1], "Thank you for using", sizeof("Thank you for using"));
        close(p[1]);
        exit(0);
    } else {
        close(p[0]);

        printf("Provide Your Input From Given Options:\n");
        printf("1. Type a to Add Money\n2. Type w to Withdraw Money\n3. Type c to Check Balance\n");

        scanf("%s", shm_ptr->sel);
        shm_ptr->b = 1000;

        write(p[1], shm_ptr, sizeof(struct shared));
        close(p[1]);

        wait(NULL);

        char message[100];
        read(p[0], message, sizeof(message));
        printf("%s\n", message);

        close(p[0]);

        shmdt(shm_ptr);
        shmctl(shm_id, IPC_RMID, NULL);

        exit(0);
    }

    return 0;
}
