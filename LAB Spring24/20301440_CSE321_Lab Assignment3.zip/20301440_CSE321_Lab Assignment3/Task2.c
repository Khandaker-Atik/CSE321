#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/ipc.h>
#include <sys/msg.h>

#define MAX_SIZE 6

struct msg {
    long int type;
    char txt[MAX_SIZE];
} message;

int main() {
    key_t key = ftok("progfile", 65);
    int msgid = msgget(key, 0666 | IPC_CREAT);

    char workspace[MAX_SIZE];
    printf("Please enter the workspace name: ");
    scanf("%s", workspace);

    if (strcmp(workspace, "cse321") != 0) {
        printf("Invalid workspace name\n");
        return 0;
    }

    message.type = 1;
    strcpy(message.txt, workspace);
    msgsnd(msgid, &message, sizeof(message), 0);
    printf("Workspace name sent to otp generator from log in: %s\n", message.txt);

    pid_t pid = fork();

    if (pid == 0) { // Child process (OTP generator)
        msgrcv(msgid, &message, sizeof(message), 1, 0);
        printf("OTP generator received workspace name from log in: %s\n", message.txt);

        pid_t pid2 = getpid();
        sprintf(message.txt, "%d", pid2);
        message.type = 2;
        msgsnd(msgid, &message, sizeof(message), 0);
        printf("OTP sent to log in from OTP generator: %s\n", message.txt);

        message.type = 3;
        msgsnd(msgid, &message, sizeof(message), 0);
        printf("OTP sent to mail from OTP generator: %s\n", message.txt);

        pid_t pid3 = fork();

        if (pid3 == 0) { // Child process (Mail)
            msgrcv(msgid, &message, sizeof(message), 3, 0);
            printf("Mail received OTP from OTP generator: %s\n", message.txt);

            message.type = 4;
            msgsnd(msgid, &message, sizeof(message), 0);
            printf("OTP sent to log in from mail: %s\n", message.txt);

            exit(0);
        } else {
            waitpid(pid3, NULL, 0);
            exit(0);
        }
    } else {
        msgrcv(msgid, &message, sizeof(message), 2, 0);
        printf("Log in received OTP from OTP generator: %s\n", message.txt);

        msgrcv(msgid, &message, sizeof(message), 4, 0);
        printf("Log in received OTP from mail: %s\n", message.txt);

        if (strcmp(message.txt, message.txt) == 0) {
            printf("OTP Verified\n");
        } else {
            printf("OTP Incorrect\n");
        }

        msgctl(msgid, IPC_RMID, NULL);
    }

    return 0;
}