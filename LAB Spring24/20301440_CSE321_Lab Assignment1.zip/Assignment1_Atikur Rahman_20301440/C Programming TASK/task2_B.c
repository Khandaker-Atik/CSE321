#include<stdio.h>
#include<string.h>
int main()
{
  char var[100], temp[100];
  int m=0,n=0;
  printf("Enter text");
  gets(var);
  
  while (var[n]!='\0')
  {
       if(!(var[n]==' ' && var[n+1]==' '))
       {
       
       temp[m]=var[n];
       m++;
       
       }
       n++;
  
  
  }
  temp[m]='\0';
  printf("After removing %s",temp);

}
