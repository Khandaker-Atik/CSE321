#include <stdio.h>
#include <string.h>

void checkEmail(char email[], char domain[])
{
    int len = strlen(email);
    int domainLen = strlen(domain);
   
    if (strcmp(&email[len-domainLen], domain) == 0) {
        printf("Email address is okay");
    } else {
        printf("Email address is outdated");
    }
}

int main()
{
    char email[100];
   
    printf("Enter an email address: ");
    scanf("%s", email);
   
    char domain[10]= "sheba.xyz";
   
    checkEmail(email, domain);
   
    return 0;
}
