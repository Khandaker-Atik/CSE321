#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdbool.h>

int main()
{
    char pass[50];
    int lower = 0;
    int upper = 0;
    int hash = 0;
    int spec = 0;

    printf("Enter pass: ");
    scanf("%s", pass);

    for (int i =0; i < strlen(pass); i++)
    {
        if (islower(pass[i]))
        lower = 1;
        if (isupper(pass[i]))
        upper = 1;
        if (isdigit(pass[i]))
        hash = 1;
        if (pass[i] == '$' ||  pass[i] == '_' || pass[i] == '#' || pass[i] == '@')
        spec = 1;
    }

    if (lower==0)
    printf("Lowercase character missing\n");
    if (upper==0)
    printf("Uppercase character missing\n");
    if (hash==0)
    printf("Digit missing\n");
    if (spec==0)
    printf("Special character missing\n");
    if (lower && upper && hash && spec)
    printf("OK\n");

    return 0;
}
 