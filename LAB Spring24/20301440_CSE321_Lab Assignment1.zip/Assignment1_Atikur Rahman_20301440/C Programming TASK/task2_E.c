#include <stdio.h>
#include <string.h>
int main()
{

    char str[100],*var1,*var2;
    printf("Enter\n");
    gets(str);
    var1=str+strlen(str);
    var2=str;
    var1--;
    while(var1>=var2)
    {
    
    if (*var1==*var2)
    
    {
    
    var1--;
    var2++;
    
    }
    else
    {
    break;
    
    }
    
    
    
    }
    if (var2>var1)
    {
    
    printf("palindrome %s",str);
    }
    else
    {
    printf("not palindrome %s",str);
    }
    return 0;





}
