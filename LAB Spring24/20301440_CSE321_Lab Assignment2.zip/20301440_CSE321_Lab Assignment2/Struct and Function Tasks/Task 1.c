#include <stdio.h>

struct Item {
    int quantity;
    float unit_price;
};

int main() {
    struct Item paratha, vegetables, mineral_water;
    int num_people;
    float total_bill, per_person_bill;

    printf("Quantity Of Paratha: ");
    scanf("%d", &paratha.quantity);
    printf("Unit Price: ");
    scanf("%f", &paratha.unit_price);

    printf("Quantity Of Vegetables: ");
    scanf("%d", &vegetables.quantity);
    printf("Unit Price: ");
    scanf("%f", &vegetables.unit_price);

    printf("Quantity Of Mineral Water: ");
    scanf("%d", &mineral_water.quantity);
    printf("Unit Price: ");
    scanf("%f", &mineral_water.unit_price);

    total_bill = paratha.quantity * paratha.unit_price +
                 vegetables.quantity * vegetables.unit_price +
                 mineral_water.quantity * mineral_water.unit_price;

    printf("Number of People: ");
    scanf("%d", &num_people);
    per_person_bill = total_bill / num_people;

    printf("Individual people will pay: %.2f tk\n", per_person_bill);

    return 0;
    
    
  }
