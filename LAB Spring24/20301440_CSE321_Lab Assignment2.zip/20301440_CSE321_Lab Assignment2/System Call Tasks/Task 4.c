#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main(int argc, char *argv[]) {
    pid_t pid;
    int status;

    
    pid = fork();

    if (pid == 0) {
        
        printf("Child process sorting the array...\n");
        execv("./sort", argv); 
    } else if (pid > 0) {
        
        printf("Parent process printing the odd/even status of the array...\n");
        wait(&status);  
        execv("./oddeven", argv);  
    } else {
        
        printf("Failed to create child process.\n");
        return 1;
    }

    return 0;
}
