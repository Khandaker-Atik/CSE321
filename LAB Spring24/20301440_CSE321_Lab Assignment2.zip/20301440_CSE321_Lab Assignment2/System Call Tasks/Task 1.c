#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_STR_LEN 100

int main(int argc, char *argv[]) {
    FILE *fp;
    char filename[50], str[MAX_STR_LEN];

    
    if (argc != 2) {
        printf("Usage: %s filename\n", argv[0]);
        return 1;
    }

    
    strcpy(filename, argv[1]);

    
    fp = fopen(filename, "a");

   
    if (fp == NULL) {
        printf("Error: Unable to open file %s\n", filename);
        return 1;
    }

    
    printf("Enter strings to write to file, enter '-1' to stop:\n");
    while (1) {
        printf("> ");
        scanf("%s", str);

        
        if (strcmp(str, "-1") == 0) {
            break;
        }

     
        fprintf(fp, "%s\n", str);
    }

    fclose(fp);

    printf("Strings written to file %s\n", filename);

    return 0;
}


