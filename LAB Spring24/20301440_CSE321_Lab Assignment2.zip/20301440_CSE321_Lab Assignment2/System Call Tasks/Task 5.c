#include <stdio.h>
#include <unistd.h>

int main() {
    pid_t pid, cpid1, cpid2, cpid3;

    pid = getpid(); 
    printf("Parent process ID: %d\n", pid);

    cpid1 = fork(); 
    if (cpid1 == 0) {
        pid = getpid();
        printf("Child process ID: %d\n", pid);

        cpid2 = fork(); 
        if (cpid2 == 0) {
            pid = getpid();
            printf("Grandchild process ID: %d\n", pid);
            return 0;
        }

        cpid3 = fork(); 
        if (cpid3 == 0) {
            pid = getpid();
            printf("Grandchild process ID: %d\n", pid);
            return 0;
        }

        
        pid = getpid();
        printf("Grandchild process ID: %d\n", pid);
        return 0;
    }

    return 0;
}


