#include <stdio.h>
#include <pthread.h>

#define NUM_THREADS 5
#define NUM_INTS 5

void *print_integers(void *thread_id) {
    int i;
    int start = *((int*)thread_id) * NUM_INTS + 1;
    int end = start + NUM_INTS - 1;

    for (i = start; i <= end; i++) {
        printf("Thread %d prints %d\n", *((int*)thread_id), i);
    }

    pthread_exit(NULL);
}

int main() {
    pthread_t threads[NUM_THREADS];
    int thread_ids[NUM_THREADS];
    int i;

    
    for (i = 0; i < NUM_THREADS; i++) {
        thread_ids[i] = i;
        pthread_create(&threads[i], NULL, print_integers, (void *)&thread_ids[i]);
    }

    
    for (i = 0; i < NUM_THREADS; i++) {
        pthread_join(threads[i], NULL);
    }

    return 0;
}

	

