#include <stdio.h>
#include <pthread.h>
#include <string.h>
#include <stdint.h>

void* sum_ascii(void* arg) {
    char* str = (char*)arg;
    int sum = 0;
    for(int i = 0; i < strlen(str); i++) {
        sum += (int)str[i];
    }
    return (void*)(intptr_t)sum;
}

void* check_results(void* arg) {
    intptr_t results[3];
    memcpy(results, arg, sizeof(results));
    if (results[0] == results[1] && results[1] == results[2]) {
        printf("Youreka\n");
    } else if (results[0] == results[1] || results[1] == results[2] || results[0] == results[2]) {
        printf("Miracle\n");
    } else {
        printf("Hasta la vista\n");
    }
    return NULL;
}

int main() {
    pthread_t threads[4];
    char* names[3] = {"Alice", "Bob", "Charlie"};
    intptr_t results[3];
    for (int i = 0; i < 3; i++) {
        pthread_create(&threads[i], NULL, sum_ascii, (void*)names[i]);
    }
    for (int i = 0; i < 3; i++) {
        pthread_join(threads[i], (void**)&results[i]);
    }
    pthread_create(&threads[3], NULL, check_results, (void*)results);
    pthread_join(threads[3], NULL);
    return 0;
}

	

